# CMD CLIENT  (Fabric, Java Edition)
Single-jar PvP client for 1.21.1 / 1.21.4 / 1.21.8 / 1.21.11 / 26.3 — by CMD Team.

Build: push to GitHub -> Actions -> "Build CMD CLIENT" -> download `CMD-CLIENT-<ver>` artifacts.
Install: Fabric Loader (0.20.1+) for that MC version, drop `CMD-CLIENT-<ver>.jar` AND `fabric-api-<ver>.jar` (same artifact) in `mods/`.
All Oneclient mods are embedded inside the jar (Jar-in-Jar). `missing-<ver>.txt` lists mods that had no build for that version.
Edit `lists/blocklist.txt` to drop a mod that misbehaves. Cape key: Right Shift (or Cosmetics button in the menu).
