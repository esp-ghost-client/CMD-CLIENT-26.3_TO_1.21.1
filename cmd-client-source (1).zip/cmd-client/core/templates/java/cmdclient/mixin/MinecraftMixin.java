package cmdclient.mixin;

import cmdclient.CmdTitleScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Minecraft.class)
public class MinecraftMixin {
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen cmdclient$swapTitle(Screen screen) {
        if (screen != null && screen.getClass() == TitleScreen.class) {
            return new CmdTitleScreen();
        }
        return screen;
    }
}
