package cmdclient.mixin;

import cmdclient.CapeManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.player.PlayerSkin;
{{SNIP_IMPORTS}}
import {{ID_IMPORT}};
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayer.class)
public class PlayerSkinMixin {
    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void cmdclient$cape(CallbackInfoReturnable<PlayerSkin> cir) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != (Object) this) return;
        {{ID_CLASS}} tex = CapeManager.texture();
        if (tex == null) return;
        PlayerSkin skin = cir.getReturnValue();
        {{SNIP_SKIN}}
        cir.setReturnValue(ns);
    }
}
