package cmdclient;

import net.fabricmc.loader.api.FabricLoader;
import {{ID_IMPORT}};

import java.nio.file.Files;
import java.nio.file.Path;

/** Capes ported from the user's own capemod (1.21.11). Cosmetics = capes only. */
public class CapeManager {
    public static final String[][] CAPES = {
        {"anime", "Anime"}, {"backroom", "Backroom"}, {"bbo", "BBO"}, {"bmw", "BMW"},
        {"cape3", "Cape 3"}, {"demon_slayer", "Demon slayer"}, {"gojo", "Gojo"},
        {"gorba_2", "Gorba 2"}, {"invitation", "Invitation"}, {"loplop", "LopLop"},
        {"naruto", "Naruto"}, {"nice", "Nice"}, {"otr", "Otr"}, {"q0ps", "Q0ps"},
        {"r_i_p", "R I P"}, {"technoblade", "Technoblade"}, {"teryak", "Teryak"},
        {"xd_khostip", "xD khostip"}, {"xxxtentacion", "XXXTentacion"},
        {"xxxtentacion_billie_eilish", "XXXTentacion x Billie"}
    };
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("cmdclient-cape.txt");
    public static String selected = CAPES[0][0];

    public static void load() {
        try {
            if (Files.exists(FILE)) selected = Files.readString(FILE).trim();
        } catch (Exception ignored) { }
    }

    public static void select(String id) {
        selected = id;
        try { Files.writeString(FILE, id); } catch (Exception ignored) { }
    }

    /** null when "no cape" is selected */
    public static {{ID_CLASS}} texture() {
        if (selected == null || selected.isEmpty()) return null;
        return {{SNIP_TEXTURE}};
    }
}
