package cmdclient;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import {{OPTIONS_IMPORT}};
import net.minecraft.network.chat.Component;

/** CMD CLIENT main menu (replaces the vanilla title screen / OneClient menu). */
public class CmdTitleScreen extends Screen {
    // Required credit line - keep exactly as the owner specified.
    public static final String CREDIT =
        "\u00a7eT\u00a77_\u00a7aHelper \u00a74Ir\u00a7ea\u00a7nr gang | \u00a7lCreator client \u00a75\u00a7lC\u00a74\u00a7lM\u00a74\u00a7lD \u00a7a\u00a7lTeam";

    private static final String[] GLYPH_C = {"01110","10001","10000","10000","10000","10001","01110"};
    private static final String[] GLYPH_M = {"10001","11011","10101","10101","10001","10001","10001"};
    private static final String[] GLYPH_D = {"11110","10001","10001","10001","10001","10001","11110"};
    private static final String[] GLYPH_L = {"10000","10000","10000","10000","10000","10000","11111"};
    private static final String[] GLYPH_I = {"01110","00100","00100","00100","00100","00100","01110"};
    private static final String[] GLYPH_E = {"11111","10000","10000","11110","10000","10000","11111"};
    private static final String[] GLYPH_N = {"10001","11001","10101","10011","10001","10001","10001"};
    private static final String[] GLYPH_T = {"11111","00100","00100","00100","00100","00100","00100"};
    private static final String[][] WORD = {GLYPH_C, GLYPH_M, GLYPH_D, null, GLYPH_C, GLYPH_L, GLYPH_I, GLYPH_E, GLYPH_N, GLYPH_T};

    private int cell, titleY;

    public CmdTitleScreen() {
        super(Component.literal("CMD CLIENT"));
    }

    @Override
    protected void init() {
        cell = Math.max(2, Math.min(7, (int) (this.width * 0.72 / 58.0)));
        titleY = Math.max(12, this.height / 2 - 92);
        int bw = 200, bh = 20, gap = 5;
        int y = titleY + 7 * cell + 26;
        y = Math.min(y, this.height - 5 * (bh + gap) - 22);
        int x = this.width / 2 - bw / 2;
        this.addRenderableWidget(Button.builder(Component.literal("Singleplayer"),
                b -> this.minecraft.setScreen(new SelectWorldScreen(this))).bounds(x, y, bw, bh).build());
        this.addRenderableWidget(Button.builder(Component.literal("Multiplayer"),
                b -> this.minecraft.setScreen(new JoinMultiplayerScreen(this))).bounds(x, y + (bh + gap), bw, bh).build());
        this.addRenderableWidget(Button.builder(Component.literal("\u00a7dCosmetics \u00a77(Capes)"),
                b -> this.minecraft.setScreen(new CapeScreen(this))).bounds(x, y + 2 * (bh + gap), bw, bh).build());
        this.addRenderableWidget(Button.builder(Component.literal("Options"),
                b -> this.minecraft.setScreen(new OptionsScreen(this, this.minecraft.options))).bounds(x, y + 3 * (bh + gap), bw, bh).build());
        this.addRenderableWidget(Button.builder(Component.literal("Quit Game"),
                b -> this.minecraft.stop()).bounds(x, y + 4 * (bh + gap), bw, bh).build());
    }

    private static int hash(int i) {
        int h = i * 0x9E3779B1;
        h ^= (h >>> 15);
        h *= 0x85EBCA6B;
        h ^= (h >>> 13);
        return h & 0x7FFFFFFF;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float delta) {
        long t = System.currentTimeMillis();
        g.fillGradient(0, 0, this.width, this.height, 0xFF050309, 0xFF1C0610);
        // falling ember particles
        for (int i = 0; i < 70; i++) {
            int x = hash(i) % Math.max(1, this.width);
            int speed = 12 + hash(i + 500) % 30;               // px / sec
            int y = (int) (((hash(i + 900) % this.height) + t * speed / 1000L) % this.height);
            int size = 1 + hash(i + 77) % 2;
            int a = 60 + hash(i + 31) % 140;
            int col = (hash(i + 5) % 3 == 0) ? 0x8A2BE2 : 0xE0143C;
            g.fill(x, this.height - y, x + size, this.height - y + size, (a << 24) | col);
        }
        // accent lines
        float pulse = 0.5f + 0.5f * (float) Math.sin(t / 600.0);
        int la = 100 + (int) (120 * pulse);
        g.fill(0, 0, this.width, 2, (la << 24) | 0xE0143C);
        g.fill(0, this.height - 16, this.width, this.height - 15, (la << 24) | 0x8A2BE2);
        // bottom bar (also covers the vanilla copyright line)
        g.fill(0, this.height - 15, this.width, this.height, 0xFF0A0610);
    }

    private void drawTitle(GuiGraphics g) {
        long t = System.currentTimeMillis();
        int advance = 6 * cell;
        int total = 3 * advance + 4 * cell + 6 * advance - cell;
        int x = (this.width - total) / 2;
        int idx = 0;
        for (String[] glyph : WORD) {
            if (glyph == null) { x += 4 * cell; continue; }
            boolean cmd = idx < 3;
            for (int r = 0; r < 7; r++) {
                for (int c = 0; c < 5; c++) {
                    if (glyph[r].charAt(c) != '1') continue;
                    int px = x + c * cell, py = titleY + r * cell;
                    g.fill(px + 1, py + 1, px + cell + 1, py + cell + 1, 0xAA000000); // shadow
                    int col;
                    if (cmd) {
                        double w = 0.5 + 0.5 * Math.sin(t / 350.0 + idx);
                        int rr = (int) (200 + 55 * w), gg = (int) (20 + 20 * w), bb = (int) (60 + 150 * (1 - w));
                        col = 0xFF000000 | (rr << 16) | (gg << 8) | bb;
                    } else {
                        double w = 0.5 + 0.5 * Math.sin(t / 250.0 - (x + c * cell) / 25.0);
                        int v = (int) (170 + 85 * w);
                        col = 0xFF000000 | (v << 16) | (v << 8) | 255;
                    }
                    g.fill(px, py, px + cell, py + cell, col);
                }
            }
            x += advance;
            idx++;
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);   // background + buttons
        drawTitle(g);
        g.drawCenteredString(this.font, Component.literal("\u00a77Minecraft {{MC}}  \u00a78|  \u00a7cPvP Edition"),
                this.width / 2, titleY + 7 * cell + 8, 0xFFFFFFFF);
        g.drawCenteredString(this.font, Component.literal(CREDIT), this.width / 2, this.height - 11, 0xFFFFFFFF);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
