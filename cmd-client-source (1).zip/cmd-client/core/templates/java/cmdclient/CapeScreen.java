package cmdclient;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class CapeScreen extends Screen {
    private final Screen parent;

    public CapeScreen(Screen parent) {
        super(Component.literal("Cosmetics"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cols = 3, bw = 110, bh = 20, gap = 4;
        int total = CapeManager.CAPES.length + 1;
        int rows = (total + cols - 1) / cols;
        int startX = (this.width - (cols * bw + (cols - 1) * gap)) / 2;
        int startY = Math.max(40, (this.height - (rows * (bh + gap))) / 2 - 10);
        for (int i = 0; i < total; i++) {
            final String id = i == 0 ? "" : CapeManager.CAPES[i - 1][0];
            String label = i == 0 ? "No cape" : CapeManager.CAPES[i - 1][1];
            int x = startX + (i % cols) * (bw + gap);
            int y = startY + (i / cols) * (bh + gap);
            this.addRenderableWidget(Button.builder(Component.literal(label), b -> CapeManager.select(id))
                    .bounds(x, y, bw, bh).build());
        }
        this.addRenderableWidget(Button.builder(Component.literal("Back"), b -> this.onClose())
                .bounds(this.width / 2 - 100, this.height - 28, 200, 20).build());
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float delta) {
        g.fillGradient(0, 0, this.width, this.height, 0xFF07040C, 0xFF1A0612);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        g.drawCenteredString(this.font, Component.literal("\u00a7c\u00a7lCMD CLIENT \u00a77- \u00a7fCosmetics (Capes)"), this.width / 2, 14, 0xFFFFFFFF);
        String cur = CapeManager.selected == null || CapeManager.selected.isEmpty() ? "none" : CapeManager.selected;
        g.drawCenteredString(this.font, Component.literal("Selected: " + cur), this.width / 2, 26, 0xFFAAAAAA);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }
}
