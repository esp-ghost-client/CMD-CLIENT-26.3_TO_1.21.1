#!/usr/bin/env python3
"""CMD CLIENT LITE (PojavLauncher / weak phones): core mod only (menu, capes, badge) with shrunken
cape textures. No embedded mods. usage: make_lite.py <core-jar> <out-jar>"""
import pathlib, sys, zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
core, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
lite = {f"assets/cmdclient/textures/cape/{p.name}": p.read_bytes() for p in (ROOT / "core" / "lite_cape").glob("*.png")}
out.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(core) as zin, zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
    for item in zin.infolist():
        data = lite.get(item.filename, zin.read(item.filename))
        zout.writestr(item, data)
print(f"LITE jar: {out} {out.stat().st_size/1024:.0f} KB")
