package cmdclient;

import net.minecraft.client.gui.GuiGraphics;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.InputStream;

/** Tiny static image drawn with plain fills (no texture API -> works the same on every MC version). */
public class PixelImage {
    public final int w, h;
    private final int[] px;

    private PixelImage(int w, int h, int[] px) { this.w = w; this.h = h; this.px = px; }

    public static PixelImage load(String path) {
        try (InputStream in = PixelImage.class.getResourceAsStream(path)) {
            BufferedImage b = ImageIO.read(in);
            int w = b.getWidth(), h = b.getHeight();
            return new PixelImage(w, h, b.getRGB(0, 0, w, h, null, 0, w));
        } catch (Throwable t) {
            return null;
        }
    }

    /** Draws into the rectangle (x,y,rw,rh). cover=true crops to keep the aspect ratio, false stretches. */
    public void draw(GuiGraphics g, int x, int y, int rw, int rh, boolean cover) {
        float scaleX = rw / (float) w, scaleY = rh / (float) h;
        float sx = scaleX, sy = scaleY;
        if (cover) { sx = sy = Math.max(scaleX, scaleY); }
        float offX = x + (rw - w * sx) / 2f, offY = y + (rh - h * sy) / 2f;
        int x1max = x + rw, y1max = y + rh;
        for (int j = 0; j < h; j++) {
            int y0 = Math.max(y, Math.round(offY + j * sy));
            int y1 = Math.min(y1max, Math.round(offY + (j + 1) * sy));
            if (y1 <= y0) continue;
            int i = 0;
            while (i < w) {
                int c = px[j * w + i];
                int k = i + 1;
                while (k < w && px[j * w + k] == c) k++;
                if ((c >>> 24) >= 128) {
                    int x0 = Math.max(x, Math.round(offX + i * sx));
                    int x1 = Math.min(x1max, Math.round(offX + k * sx));
                    if (x1 > x0) g.fill(x0, y0, x1, y1, c | 0xFF000000);
                }
                i = k;
            }
        }
    }
}
