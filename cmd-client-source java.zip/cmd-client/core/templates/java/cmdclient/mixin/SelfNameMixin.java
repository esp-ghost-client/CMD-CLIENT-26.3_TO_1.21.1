package cmdclient.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Show your own name tag (with the CMD badge) when you look at yourself in F5 / third person. */
@Mixin(LivingEntityRenderer.class)
public class SelfNameMixin {
    @Inject(method = "shouldShowName", at = @At("RETURN"), cancellable = true, require = 0)
    private void cmdclient$selfTag({{SHOWNAME_PARAMS}}) {
        Minecraft mc = Minecraft.getInstance();
        if (e == mc.player && !cir.getReturnValueZ() && !mc.options.getCameraType().isFirstPerson()) {
            cir.setReturnValue(true);
        }
    }
}
