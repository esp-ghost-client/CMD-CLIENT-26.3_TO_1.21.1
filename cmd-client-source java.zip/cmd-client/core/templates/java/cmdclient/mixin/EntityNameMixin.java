package cmdclient.mixin;

import cmdclient.BadgeManager;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityNameMixin {
    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true, require = 0)
    private void cmdclient$badge(CallbackInfoReturnable<Component> cir) {
        Entity self = (Entity) (Object) this;
        if (!(self instanceof Player)) return;
        if (!BadgeManager.hasBadge(self)) return;
        cir.setReturnValue(Component.empty().append(cir.getReturnValue()).append(" ").append(BadgeManager.badge()));
    }
}
