package cmdclient;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.world.entity.Entity;
import {{ID_IMPORT}};
{{SNIP_FONTIMPORT}}

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * CMD badge (eagle) next to the names of CMD CLIENT users.
 * - you always get it yourself
 * - every other CMD CLIENT user in the world gets it automatically: each client registers its own name in the
 *   CMD registry (a free Firebase Realtime Database, REST) and downloads the list of all registered names.
 * Registry URL is baked in from lists/registry_url.txt (override: config/cmdclient.properties -> registry_url=)
 */
public class BadgeManager {
    private static final Set<String> USERS = ConcurrentHashMap.newKeySet();
    private static final Style BADGE_STYLE = {{SNIP_FONTSTYLE}};

    public static void init() {
        Thread t = new Thread(() -> {
            while (true) {
                try { refresh(); } catch (Throwable ignored) { }
                try { Thread.sleep(10 * 60 * 1000L); } catch (InterruptedException e) { return; }
            }
        }, "cmdclient-registry");
        t.setDaemon(true);
        t.start();
    }

    private static final String DEFAULT_REGISTRY = "{{REGISTRY_URL}}";
    private static volatile boolean registered = false;

    private static String registryUrl() throws Exception {
        Path cfg = FabricLoader.getInstance().getConfigDir().resolve("cmdclient.properties");
        if (Files.exists(cfg)) {
            for (String line : Files.readAllLines(cfg)) {
                if (line.startsWith("registry_url=")) {
                    String u = line.substring("registry_url=".length()).trim();
                    if (!u.isEmpty()) return u;
                }
            }
        }
        return DEFAULT_REGISTRY;
    }

    /** Everyone who runs CMD CLIENT registers his own name once; everyone downloads the full list. */
    private static void refresh() throws Exception {
        String base = registryUrl().trim();
        while (base.endsWith("/")) base = base.substring(0, base.length() - 1);
        if (!base.startsWith("http")) return;
        HttpClient http = HttpClient.newHttpClient();

        if (!registered) {
            String me = Minecraft.getInstance().getUser().getName().toLowerCase(Locale.ROOT);
            HttpResponse<String> r = http.send(HttpRequest.newBuilder(URI.create(base + "/users/" + me + ".json"))
                    .header("Content-Type", "application/json")
                    .PUT(HttpRequest.BodyPublishers.ofString("true")).build(), HttpResponse.BodyHandlers.ofString());
            // 200 = registered now, 401 = already registered earlier (rules forbid overwriting)
            if (r.statusCode() == 200 || r.statusCode() == 401) registered = true;
        }

        HttpResponse<String> r = http.send(HttpRequest.newBuilder(URI.create(base + "/users.json")).GET().build(),
                HttpResponse.BodyHandlers.ofString());
        JsonElement root = JsonParser.parseString(r.body());
        if (root.isJsonObject()) {
            for (String k : root.getAsJsonObject().keySet()) USERS.add(k.toLowerCase(Locale.ROOT));
        } else if (root.isJsonArray()) {
            for (JsonElement e : root.getAsJsonArray()) if (e.isJsonPrimitive()) USERS.add(e.getAsString().toLowerCase(Locale.ROOT));
        }
    }

    public static boolean hasBadge(Entity player) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && player == mc.player) return true;
        return USERS.contains(player.getScoreboardName().toLowerCase(Locale.ROOT));
    }

    public static MutableComponent badge() {
        return Component.literal("\ue000").withStyle(BADGE_STYLE);
    }
}
