package cmdclient.pvp;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class PvpConfig {
    public static boolean toggleSprint = true;
    public static boolean fullbright = false;
    public static boolean showFps = true;
    public static boolean showCps = true;
    public static boolean showCoords = false;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("cmdclient-pvp.properties");
    }

    public static void load() {
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file())) {
            p.load(in);
        } catch (Exception e) {
            return;
        }
        toggleSprint = Boolean.parseBoolean(p.getProperty("toggleSprint", "true"));
        fullbright = Boolean.parseBoolean(p.getProperty("fullbright", "false"));
        showFps = Boolean.parseBoolean(p.getProperty("showFps", "true"));
        showCps = Boolean.parseBoolean(p.getProperty("showCps", "true"));
        showCoords = Boolean.parseBoolean(p.getProperty("showCoords", "false"));
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("toggleSprint", String.valueOf(toggleSprint));
        p.setProperty("fullbright", String.valueOf(fullbright));
        p.setProperty("showFps", String.valueOf(showFps));
        p.setProperty("showCps", String.valueOf(showCps));
        p.setProperty("showCoords", String.valueOf(showCoords));
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "CMD CLIENT PvP modules");
        } catch (Exception ignored) { }
    }
}
