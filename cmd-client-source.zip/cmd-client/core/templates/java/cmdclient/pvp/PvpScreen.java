package cmdclient.pvp;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** CMD PvP menu: switch the PvP modules on / off (saved to config/cmdclient-pvp.properties). */
public class PvpScreen extends Screen {
    private final Screen parent;

    public PvpScreen(Screen parent) {
        super(Component.literal("CMD PvP"));
        this.parent = parent;
    }

    private static String label(String name, boolean on) {
        return name + ": " + (on ? "\u00a7aON" : "\u00a7cOFF");
    }

    private Button toggle(int y, String name, java.util.function.BooleanSupplier get, java.util.function.Consumer<Boolean> set) {
        final Button[] ref = new Button[1];
        ref[0] = Button.builder(Component.literal(label(name, get.getAsBoolean())), b -> {
            set.accept(!get.getAsBoolean());
            PvpConfig.save();
            ref[0].setMessage(Component.literal(label(name, get.getAsBoolean())));
        }).bounds(this.width / 2 - 100, y, 200, 20).build();
        return ref[0];
    }

    @Override
    protected void init() {
        int y = Math.max(44, this.height / 2 - 70);
        this.addRenderableWidget(toggle(y, "Toggle Sprint", () -> PvpConfig.toggleSprint, v -> PvpConfig.toggleSprint = v));
        this.addRenderableWidget(toggle(y + 24, "Fullbright", () -> PvpConfig.fullbright, v -> PvpConfig.fullbright = v));
        this.addRenderableWidget(toggle(y + 48, "FPS", () -> PvpConfig.showFps, v -> PvpConfig.showFps = v));
        this.addRenderableWidget(toggle(y + 72, "CPS", () -> PvpConfig.showCps, v -> PvpConfig.showCps = v));
        this.addRenderableWidget(toggle(y + 96, "Coordinates", () -> PvpConfig.showCoords, v -> PvpConfig.showCoords = v));
        this.addRenderableWidget(Button.builder(Component.literal("Back"), b -> this.onClose())
                .bounds(this.width / 2 - 100, this.height - 28, 200, 20).build());
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float delta) {
        g.fillGradient(0, 0, this.width, this.height, 0xFF07040C, 0xFF1A0612);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        g.drawCenteredString(this.font, Component.literal("\u00a7c\u00a7lCMD CLIENT \u00a77- \u00a7fPvP Menu"), this.width / 2, 16, 0xFFFFFFFF);
        g.drawCenteredString(this.font, Component.literal("\u00a77Works on PC and PojavLauncher"), this.width / 2, 28, 0xFFAAAAAA);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }
}
