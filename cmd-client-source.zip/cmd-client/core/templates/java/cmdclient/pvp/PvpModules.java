package cmdclient.pvp;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import {{ID_IMPORT}};

import java.util.ArrayDeque;

/** CMD PvP modules that work everywhere (also PojavLauncher): Toggle Sprint, Fullbright, FPS / CPS / Coords HUD. */
public class PvpModules {
    public static KeyMapping openKey;
    private static final ArrayDeque<Long> clicks = new ArrayDeque<>();
    private static boolean lastLeft = false;
    private static boolean nightVisionApplied = false;
    private static int frames = 0, fps = 0;
    private static long lastSecond = System.currentTimeMillis();

    public static void init() {
        PvpConfig.load();
        {{SNIP_PVPKEY}}
        KeyBindingHelper.registerKeyBinding(openKey);

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openKey.consumeClick()) {
                if (mc.screen == null) mc.setScreen(new PvpScreen(null));
            }
            if (mc.player == null) return;

            // Toggle Sprint
            if (PvpConfig.toggleSprint && mc.options.keyUp.isDown() && !mc.player.isShiftKeyDown()) {
                mc.options.keySprint.setDown(true);
            }

            // Fullbright (client-side night vision)
            if (PvpConfig.fullbright) {
                if (!mc.player.hasEffect(MobEffects.NIGHT_VISION) || mc.player.tickCount % 100 == 0) {
                    mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false));
                }
                nightVisionApplied = true;
            } else if (nightVisionApplied) {
                mc.player.removeEffect(MobEffects.NIGHT_VISION);
                nightVisionApplied = false;
            }

            // CPS (left clicks in the last second)
            boolean left = mc.mouseHandler.isLeftPressed();
            long now = System.currentTimeMillis();
            if (left && !lastLeft) clicks.add(now);
            lastLeft = left;
            while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.pollFirst();
        });

        HudRenderCallback.EVENT.register((g, delta) -> {
            frames++;
            long now = System.currentTimeMillis();
            if (now - lastSecond >= 1000) { fps = frames; frames = 0; lastSecond = now; }
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.options.hideGui) return;
            int y = 6;
            if (PvpConfig.showFps) { g.drawString(mc.font, "FPS: " + fps, 6, y, 0xFFFFFFFF, true); y += 10; }
            if (PvpConfig.showCps) { g.drawString(mc.font, "CPS: " + clicks.size(), 6, y, 0xFFFFFFFF, true); y += 10; }
            if (PvpConfig.showCoords) {
                String c = (int) mc.player.getX() + " " + (int) mc.player.getY() + " " + (int) mc.player.getZ();
                g.drawString(mc.font, "XYZ: " + c, 6, y, 0xFFFFFFFF, true);
            }
        });
    }
}
