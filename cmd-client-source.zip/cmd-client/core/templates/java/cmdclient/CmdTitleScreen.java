package cmdclient;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import {{OPTIONS_IMPORT}};
import net.minecraft.network.chat.Component;

/** CMD CLIENT main menu: static forest background + right-side panel (logo + the important buttons). */
public class CmdTitleScreen extends Screen {
    // Required credit line - keep exactly as the owner specified.
    public static final String CREDIT =
        "\u00a7eT\u00a77_\u00a7aHelper \u00a7aI\u00a7rra\u00a74n \u00a77gang \u00a7r| \u00a7f\u00a7lCreator client \u00a75\u00a7lC\u00a74\u00a7lM\u00a74\u00a7lD \u00a7a\u00a7lTeam";

    private static PixelImage bg, logo;
    private static boolean loaded;

    private int panelW;

    public CmdTitleScreen() {
        super(Component.literal("CMD CLIENT"));
    }

    @Override
    protected void init() {
        if (!loaded) {
            bg = PixelImage.load("/assets/cmdclient/textures/gui/bg.png");
            logo = PixelImage.load("/assets/cmdclient/textures/gui/logo_gui.png");
            loaded = true;
        }
        panelW = Math.max(120, Math.min(170, (int) (this.width * 0.28)));
        int bw = panelW - 20, bh = 20, gap = 4;
        int x = this.width - panelW + 10;
        int y = Math.min(this.height / 2 - 14, this.height - 6 * (bh + gap) - 24);
        this.addRenderableWidget(Button.builder(Component.literal("Singleplayer"),
                b -> this.minecraft.setScreen(new SelectWorldScreen(this))).bounds(x, y, bw, bh).build());
        this.addRenderableWidget(Button.builder(Component.literal("Multiplayer"),
                b -> this.minecraft.setScreen(new JoinMultiplayerScreen(this))).bounds(x, y + (bh + gap), bw, bh).build());
        this.addRenderableWidget(Button.builder(Component.literal("\u00a7dCosmetics"),
                b -> this.minecraft.setScreen(new CapeScreen(this))).bounds(x, y + 2 * (bh + gap), bw, bh).build());
        this.addRenderableWidget(Button.builder(Component.literal("\u00a7bPvP Menu"),
                b -> { Screen s = PvpBridge.open(this); if (s != null) this.minecraft.setScreen(s); })
                .bounds(x, y + 3 * (bh + gap), bw, bh).build());
        this.addRenderableWidget(Button.builder(Component.literal("Options"),
                b -> this.minecraft.setScreen(new OptionsScreen(this, this.minecraft.options))).bounds(x, y + 4 * (bh + gap), bw, bh).build());
        this.addRenderableWidget(Button.builder(Component.literal("Quit Game"),
                b -> this.minecraft.stop()).bounds(x, y + 5 * (bh + gap), bw, bh).build());
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float delta) {
        if (bg != null) {
            bg.draw(g, 0, 0, this.width, this.height, true);
        } else {
            g.fillGradient(0, 0, this.width, this.height, 0xFF0B1A1C, 0xFF16303A);
        }
        // right panel
        g.fill(this.width - panelW, 0, this.width, this.height, 0xB4060810);
        g.fill(this.width - panelW, 0, this.width - panelW + 1, this.height, 0x55FFFFFF);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);   // background + buttons
        int cx = this.width - panelW / 2;
        int size = Math.max(32, Math.min(56, panelW - 70));
        if (logo != null) logo.draw(g, cx - size / 2, 12, size, size, false);
        g.drawCenteredString(this.font, Component.literal("\u00a7f\u00a7lCMD CLIENT"), cx, 12 + size + 4, 0xFFFFFFFF);
        g.drawCenteredString(this.font, Component.literal("\u00a78build {{BUILD_ID}}"), 40, this.height - 26, 0xFF888888);
        // bottom bar with the credit line
        g.fill(0, this.height - 15, this.width, this.height, 0xCC05060A);
        g.drawCenteredString(this.font, Component.literal(CREDIT), this.width / 2, this.height - 11, 0xFFFFFFFF);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
