package cmdclient;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import {{ID_IMPORT}};

public class CmdClient implements ClientModInitializer {
    public static KeyMapping openMenu;

    @Override
    public void onInitializeClient() {
        CapeManager.load();
        BadgeManager.init();
        PvpBridge.init();
        {{SNIP_KEYMAPPING}}
        KeyBindingHelper.registerKeyBinding(openMenu);
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openMenu.consumeClick()) {
                if (mc.screen == null) mc.setScreen(new CapeScreen(null));
            }
        });
    }
}
