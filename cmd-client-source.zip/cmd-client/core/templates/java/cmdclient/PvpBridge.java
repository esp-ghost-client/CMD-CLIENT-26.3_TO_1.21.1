package cmdclient;

import net.minecraft.client.gui.screens.Screen;

/** Loads the optional PvP module package by reflection, so the rest of the client still builds/works without it. */
public class PvpBridge {
    public static void init() {
        try {
            Class.forName("cmdclient.pvp.PvpModules").getMethod("init").invoke(null);
        } catch (Throwable ignored) { }
    }

    /** @return the PvP menu screen, or null when the PvP package is not available */
    public static Screen open(Screen parent) {
        try {
            return (Screen) Class.forName("cmdclient.pvp.PvpScreen").getConstructor(Screen.class).newInstance(parent);
        } catch (Throwable t) {
            return null;
        }
    }
}
