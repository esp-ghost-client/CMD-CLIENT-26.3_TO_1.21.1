package cmdclient.mixin;

import cmdclient.BadgeManager;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Entity.class, Player.class})
public class EntityNameMixin {
    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true, require = 0)
    private void cmdclient$badge(CallbackInfoReturnable<Component> cir) {
        Entity self = (Entity) (Object) this;
        if (!(self instanceof Player)) return;
        if (!BadgeManager.hasBadge(self)) return;
        Component original = cir.getReturnValue();
        if (original == null || original.getString().contains("\ue000")) return;   // Player overrides Entity: never add it twice
        cir.setReturnValue(Component.empty().append(original).append(" ").append(BadgeManager.badge()));
    }
}
