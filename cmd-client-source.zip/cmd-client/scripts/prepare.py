#!/usr/bin/env python3
"""Generate work/<mc>/ (a complete Loom project for the CMD CLIENT core mod) from templates.

usage: python scripts/prepare.py 1.21.11
"""
import json, pathlib, re, shutil, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
mc = sys.argv[1]
nopvp = "nopvp" in sys.argv[2:]   # fallback build without the optional PvP package

# family: A = 1.21.1 | B = 1.21.4, 1.21.8 | C = 1.21.11 | D = 26.x (unobfuscated)
VERSIONS = {
    "1.21.1":  dict(fam="A", fapi="0.116.18+1.21.1", java=21),
    "1.21.4":  dict(fam="B", fapi="0.119.4+1.21.4",  java=21),
    "1.21.8":  dict(fam="B", fapi="0.136.1+1.21.8",  java=21),
    "1.21.11": dict(fam="C", fapi="0.141.6+1.21.11", java=21),
    "26.3":    dict(fam="D", fapi="0.167.0+26.3",    java=25),
}
cfg = VERSIONS[mc]
fam = cfg["fam"]
new_api = fam in ("C", "D")  # Identifier + ClientAsset + KeyMapping.Category

subs = {
    "{{ID_CLASS}}": "Identifier" if new_api else "ResourceLocation",
    "{{ID_IMPORT}}": "net.minecraft.resources.Identifier" if new_api else "net.minecraft.resources.ResourceLocation",
    "{{OPTIONS_IMPORT}}": "net.minecraft.client.gui.screens.options.OptionsScreen",
    "{{PLAYERSKIN_IMPORT}}": ("net.minecraft.client.resources.PlayerSkin" if fam in ("A", "B")
                              else "net.minecraft.world.entity.player.PlayerSkin"),
    "{{REGISTRY_URL}}": "".join(l.strip() for l in (ROOT / "lists" / "registry_url.txt").read_text().splitlines()
                                if l.strip() and not l.startswith("#")),
    "{{BUILD_NUM}}": re.sub(r"\D", "", (ROOT / "lists" / "build_id.txt").read_text()).lstrip("0") or "0",
    "{{BUILD_ID}}": (ROOT / "lists" / "build_id.txt").read_text().strip(),
    "{{MC}}": mc,
    "{{JAVA}}": str(cfg["java"]),
    "{{MIXIN_JAVA}}": "JAVA_%d" % cfg["java"],
    "{{FAPI}}": cfg["fapi"],
}

src_tpl = ROOT / "core" / "templates"
out = ROOT / "work" / mc
if out.exists():
    shutil.rmtree(out)
(out / "src/main/java/cmdclient/mixin").mkdir(parents=True)
(out / "src/main/resources").mkdir(parents=True)


def render(text, extra=None):
    s = dict(subs)
    if extra:
        s.update(extra)
    for _ in range(2):  # twice: snippets contain placeholders themselves
        for k, v in s.items():
            text = text.replace(k, v)
    return text


# ---- java sources (family-specific snippets live in snippets/<name>.<NEW|OLD>.txt)
snip = lambda n: (src_tpl / "snippets" / f"{n}.{'NEW' if new_api else 'OLD'}.txt").read_text()
extra = {
    "{{SNIP_KEYMAPPING}}": snip("keymapping"),
    "{{SNIP_PVPKEY}}": snip("pvpkey"),
    "{{SNIP_SKIN}}": snip("skin"),
    "{{SNIP_TEXTURE}}": snip("texture"),
    "{{SNIP_IMPORTS}}": snip("imports"),
    "{{SNIP_FONTSTYLE}}": snip("fontstyle").strip(),
    "{{SNIP_FONTIMPORT}}": snip("fontimport"),
    "{{SHOWNAME_PARAMS}}": ("LivingEntity e, CallbackInfoReturnable<Boolean> cir" if fam == "A"
                            else "LivingEntity e, double d, CallbackInfoReturnable<Boolean> cir"),
}
for f in (src_tpl / "java").rglob("*.java"):
    rel = f.relative_to(src_tpl / "java")
    if nopvp and "pvp" in rel.parts:
        continue
    dst = out / "src/main/java" / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(render(f.read_text(), extra))

# ---- resources
res = out / "src/main/resources"
shutil.copytree(ROOT / "core" / "common" / "assets", res / "assets")
(res / "cmdclient.mixins.json").write_text(render((src_tpl / "cmdclient.mixins.json").read_text()))
(res / "fabric.mod.json").write_text(render((src_tpl / "fabric.mod.json").read_text()))

# ---- gradle
if fam == "D":
    plugin = "net.fabricmc.fabric-loom"
    loom_ver = "1.15-SNAPSHOT"
    deps = """    minecraft "com.mojang:minecraft:{{MC}}"
    implementation "net.fabricmc:fabric-loader:0.20.1"
    implementation "net.fabricmc.fabric-api:fabric-api:{{FAPI}}"
"""
    jar_task = "jar"
else:
    plugin = "fabric-loom"
    loom_ver = "1.14.10"
    deps = """    minecraft "com.mojang:minecraft:{{MC}}"
    mappings loom.officialMojangMappings()
    modImplementation "net.fabricmc:fabric-loader:0.20.1"
    modImplementation "net.fabricmc.fabric-api:fabric-api:{{FAPI}}"
"""
    jar_task = "jar"

(out / "build.gradle").write_text(render(f"""plugins {{
    id '{plugin}' version '{loom_ver}'
}}

version = '1.0.0'
group = 'cmdclient'
base {{ archivesName = 'cmdclient-{{{{MC}}}}' }}

repositories {{
    maven {{ url 'https://maven.fabricmc.net/' }}
}}

dependencies {{
{deps}}}

tasks.withType(JavaCompile).configureEach {{
    options.encoding = 'UTF-8'
    options.release = {{{{JAVA}}}}
}}

java {{
    sourceCompatibility = JavaVersion.VERSION_{{{{JAVA}}}}
    targetCompatibility = JavaVersion.VERSION_{{{{JAVA}}}}
}}
"""))
(out / "settings.gradle").write_text("""pluginManagement {
    repositories {
        maven { url 'https://maven.fabricmc.net/' }
        gradlePluginPortal()
        mavenCentral()
    }
}
rootProject.name = 'cmdclient'
""")
(out / "gradle.properties").write_text("org.gradle.jvmargs=-Xmx2G\norg.gradle.daemon=false\n")
print(f"prepared {out} (family {fam})")
