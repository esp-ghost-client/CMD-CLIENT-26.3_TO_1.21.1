#!/usr/bin/env python3
"""Build the single-jar CMD CLIENT for one Minecraft version.

Takes the compiled core mod jar and embeds every client mod of the Oneclient list as
Fabric Jar-in-Jar (META-INF/jars/*.jar), so the result is ONE .jar (no .mrpack).

usage: python scripts/assemble.py <mc> <core-jar> <out-jar>

1.21.1 / 1.21.11 / 26.3 : exact file list from the uploaded Oneclient mrpacks (sha512 verified).
1.21.4 / 1.21.8         : no mrpack -> every project of the 1.21.11 + 1.21.1 lists is looked up on the
                          Modrinth API for that version; projects that have no build are skipped
                          and written to missing-<mc>.txt.
"""
import hashlib, json, pathlib, re, sys, urllib.parse, urllib.request, zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
mc, core_jar, out_jar = sys.argv[1], pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3])
UA = {"User-Agent": "CMD-CLIENT-build/1.0 (github actions; CMD Team)"}

LISTS = {"1.21.1": "oneclient-1.21.1.json", "1.21.11": "oneclient-1.21.11.json", "26.3": "oneclient-26.3.json"}
BLOCK = {l.strip().lower() for l in (ROOT / "lists" / "blocklist.txt").read_text().splitlines()
         if l.strip() and not l.startswith("#")}


def get(url, binary=False):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=120) as r:
        data = r.read()
    return data if binary else json.loads(data)


def project_id(url):
    m = re.search(r"cdn\.modrinth\.com/data/([A-Za-z0-9]+)/", url)
    return m.group(1) if m else None


def client_mods(index):
    return [f for f in index["files"] if f["path"].startswith("mods/") and f["env"]["client"] != "unsupported"]


def blocked(name):
    n = name.lower()
    if n.startswith("fabric-api"):   # shipped beside the client jar (fabric-api/ folder), not embedded
        return True
    return any(b in n for b in BLOCK)


jars = []  # (filename, bytes)
missing = []

if mc in LISTS:
    idx = json.loads((ROOT / "lists" / LISTS[mc]).read_text())
    for f in client_mods(idx):
        name = pathlib.Path(f["path"]).name
        if blocked(name):
            print("blocked:", name); continue
        try:
            data = get(f["downloads"][0], binary=True)
        except Exception as e:
            print("DOWNLOAD FAILED", name, e); missing.append(name); continue
        if hashlib.sha512(data).hexdigest() != f["hashes"]["sha512"]:
            print("HASH MISMATCH", name); missing.append(name + " (hash mismatch)"); continue
        jars.append((name, data))
else:
    ids = {}
    for key in ("oneclient-1.21.11.json", "oneclient-1.21.1.json"):
        idx = json.loads((ROOT / "lists" / key).read_text())
        for f in client_mods(idx):
            pid = project_id(f["downloads"][0])
            if pid and pid not in ids:
                ids[pid] = pathlib.Path(f["path"]).name
    for pid, label in ids.items():
        if blocked(label):
            continue
        q = urllib.parse.urlencode({"loaders": '["fabric"]', "game_versions": json.dumps([mc])})
        try:
            vers = get(f"https://api.modrinth.com/v2/project/{pid}/version?{q}")
        except Exception as e:
            print("API FAILED", label, e); missing.append(label); continue
        vers = [v for v in vers if v["version_type"] in ("release", "beta", "alpha")]
        vers.sort(key=lambda v: ({"release": 0, "beta": 1, "alpha": 2}[v["version_type"]], ""))
        # newest release first (API already returns newest first within a type)
        best = None
        for t in ("release", "beta", "alpha"):
            c = [v for v in vers if v["version_type"] == t]
            if c:
                best = c[0]; break
        if not best:
            print("no build for", mc, ":", label); missing.append(label); continue
        fl = next((x for x in best["files"] if x.get("primary")), best["files"][0])
        if not fl["filename"].endswith(".jar"):
            missing.append(label); continue
        data = get(fl["url"], binary=True)
        if hashlib.sha512(data).hexdigest() != fl["hashes"]["sha512"]:
            print("HASH MISMATCH", fl["filename"]); missing.append(label); continue
        jars.append((fl["filename"], data))

# ---- make sure each nested jar is a real Fabric mod (has fabric.mod.json) and de-duplicate by mod id
import io
seen, final, infos = {}, [], {}
for name, data in jars:
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            meta = json.loads(z.read("fabric.mod.json").decode("utf-8-sig"), strict=False)
        mid = meta["id"]
    except Exception:
        print("not a fabric mod, skipped:", name); missing.append(name + " (not fabric)"); continue
    if mid in seen:
        print("duplicate mod id", mid, "->", name, "(kept", seen[mid], ")"); continue
    seen[mid] = name
    final.append((name, data))
    prov = set()
    for p_ in meta.get("provides", []) or []:
        prov.add(p_ if isinstance(p_, str) else p_.get("id", ""))
    infos[name] = (mid, prov, dict(meta.get("depends", {}) or {}))

# ---- POJAV (lite) mod set: small PvP/QoL mods from lite_allow.txt + the libraries they need (nothing needing OneConfig/Kotlin)
ALLOW = [l.strip().lower() for l in (ROOT / "lists" / "lite_allow.txt").read_text().splitlines()
         if l.strip() and not l.startswith("#")]
DENY_IDS = {"oneconfig", "polycompose", "fabric-language-kotlin", "polyplus", "polydium", "polyfrost"}
id2name = {}
for n_, (mid_, prov_, _d) in infos.items():
    id2name[mid_] = n_
    for p_ in prov_:
        id2name[p_] = n_


def builtin(i):
    return i in ("minecraft", "java", "fabricloader", "fabric-api", "fabric", "mixinextras") or \
        (i.startswith("fabric-") and i != "fabric-language-kotlin")


def closure(name, acc, stack=()):
    """add name + required libs to acc; return False if a requirement cannot be met"""
    if name in acc:
        return True
    if name in stack:
        return True
    deps = infos[name][2]
    needed = []
    for dep in deps:
        if builtin(dep):
            continue
        if dep in DENY_IDS or dep not in id2name:
            print("lite: skipping", name, "- needs", dep)
            return False
        needed.append(id2name[dep])
    tmp = set()
    for dn in needed:
        sub = set(acc) | tmp
        if not closure(dn, sub, stack + (name,)):
            return False
        tmp |= sub
    acc |= tmp
    acc.add(name)
    return True


lite_names, lite_report = set(), []
for n_ in sorted(infos):
    low = n_.lower()
    if any(a in low for a in ALLOW):
        acc = set()
        if closure(n_, acc):
            lite_names |= acc
            lite_report.append("lite + " + n_)
        else:
            lite_report.append("lite - " + n_ + " (needs a library that is not available without OneConfig/Kotlin)")
lite_dir = out_jar.parent / "lite-mods"
lite_dir.mkdir(parents=True, exist_ok=True)
data_by_name = dict(final)
for n_ in sorted(lite_names):
    (lite_dir / n_).write_bytes(data_by_name[n_])
missing.extend(lite_report)
missing.append("lite total: " + str(len(lite_names)) + " jars, " +
               str(round(sum(len(data_by_name[n_]) for n_ in lite_names) / 1e6, 1)) + " MB")

# ---- if the core mod failed to compile, fall back to a stub (name only) so the user still gets a jar
if str(core_jar) == "STUB" or not core_jar.exists():
    print("!!! core mod missing -> building STUB core (no custom menu / capes for this version)")
    core_jar = pathlib.Path("core-stub.jar")
    with zipfile.ZipFile(core_jar, "w") as z:
        z.writestr("fabric.mod.json", json.dumps({
            "schemaVersion": 1, "id": "cmdclient", "version": "1.0.0", "name": "CMD CLIENT",
            "description": "CMD CLIENT (mods only build - core failed to compile)",
            "environment": "client", "depends": {"minecraft": mc}}))

# ---- write the combined jar
out_jar.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(core_jar) as zin, zipfile.ZipFile(out_jar, "w", zipfile.ZIP_DEFLATED) as zout:
    for item in zin.infolist():
        data = zin.read(item.filename)
        if item.filename == "fabric.mod.json":
            meta = json.loads(data.decode("utf-8"))
            meta["jars"] = [{"file": f"META-INF/jars/{n}"} for n, _ in final]
            data = json.dumps(meta, indent=2).encode("utf-8")
        zout.writestr(item, data)
    for n, d in final:
        zout.writestr(f"META-INF/jars/{n}", d)

import shutil
shutil.copy(ROOT / "fabric-api" / f"fabric-api-{mc}.jar", out_jar.parent / f"fabric-api-{mc}.jar")
(out_jar.parent / f"missing-{mc}.txt").write_text("\n".join(missing) + "\n")
print(f"\n=== CMD CLIENT {mc}: {len(final)} mods embedded, {len(missing)} missing/skipped -> {out_jar} "
      f"({out_jar.stat().st_size/1e6:.1f} MB)")
