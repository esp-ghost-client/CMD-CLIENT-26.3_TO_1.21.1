#!/usr/bin/env python3
"""CMD CLIENT POJAV (lite): core mod (menu, capes, badge, PvP menu) with shrunken cape textures
+ the small mod set that assemble.py put into <dist>/lite-mods/ (Jar-in-Jar).
usage: make_lite.py <core-jar> <out-jar>"""
import json, pathlib, sys, zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
core, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
lite = {f"assets/cmdclient/textures/cape/{p.name}": p.read_bytes() for p in (ROOT / "core" / "lite_cape").glob("*.png")}
mods_dir = out.parent / "lite-mods"
mods = sorted(mods_dir.glob("*.jar")) if mods_dir.exists() else []
out.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(core) as zin, zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
    for item in zin.infolist():
        data = lite.get(item.filename, zin.read(item.filename))
        if item.filename == "fabric.mod.json" and mods:
            meta = json.loads(data.decode("utf-8"))
            meta["jars"] = [{"file": f"META-INF/jars/{m.name}"} for m in mods]
            data = json.dumps(meta, indent=2).encode("utf-8")
        zout.writestr(item, data)
    for m in mods:
        zout.writestr(f"META-INF/jars/{m.name}", m.read_bytes())
print(f"POJAV jar: {out} {out.stat().st_size/1e6:.1f} MB ({len(mods)} mods nested)")
